<footer>
  <div class="row">
    <div class="col-lg-12">
      <p>Copyright &copy; BiliKreasi 2016</p>
    </div>
  </div>
</footer>