<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Bilikreasi</title>
</head>

<body>

    <?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Page Content -->
    <div class="container">
      <?php echo $__env->make('layout.page-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldContent('content'); ?>
      <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- /.container -->

    <script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>
    <script type="text/javascript"> var myPrefix = '<?php echo e(asset('')); ?>';</script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">
</body>

</html>
