<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo e(route('home.index')); ?>">
        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Bilikreasi">
      </a>
    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="navbar-collapse">
      <ul class="nav navbar-nav">
        <li class='dropdown category-idea'>
          <a href="#" class="text-center" data-toggle="dropdown">Kategori</a>
          <ul class="dropdown-menu">
            <div class="list-group">
              <a href="<?php echo e(route('search.index').'?category=business'); ?>" class="list-group-item"><i class="fa fa-money"></i> Usaha</a>
              <a href="<?php echo e(route('search.index').'?category=community'); ?>"" class="list-group-item"><i class="fa fa-users"></i> Komunitas</a>
              <a href="<?php echo e(route('search.index').'?category=campaign'); ?>"" class="list-group-item"><i class="fa fa-bullhorn"></i> Kampanye</a>
              <a href="<?php echo e(route('search.index').'?category=project'); ?>"" class="list-group-item"><i class="fa fa-suitcase"></i> Proyek</a>
              <a href="<?php echo e(route('search.index').'?category=event'); ?>"" class="list-group-item"><i class="fa fa-calendar"></i> Kegiatan</a>
              <a href="<?php echo e(route('search.index').'?category=other'); ?>"" class="list-group-item"><i class="fa fa-bars"></i> Lain</a>
            </div>
          </ul>
        </li>
        <li class="search-input">
          <?php echo Form::open(['route' => ['search.index'], 'method' => 'GET']); ?>

          <div class="input-group col-md-12">
            <?php echo Form::text('q', app('request')->input('q', ''), ['class' => 'form-control input-lg', 'placeholder' => 'Cari Ide']); ?>

            <span class="input-group-btn">
              <button type='submit' class="btn btn-lg" type="button">
                <i class="fa fa-search"></i>
              </button>
            </span>
          </div>
          <?php echo Form::close(); ?>

        </li>
      </ul>
      <?php if(\Auth::check()): ?>
      <ul class="nav navbar-nav user-menu-mobile hidden-sm hidden-md hidden-lg">
        <li class="list-group">
          <a href="#" class="list-group-item"><i class="fa fa-money"></i> Usaha</a>
          <a href="#" class="list-group-item"><i class="fa fa-users"></i> Komunitas</a>
          <a href="#" class="list-group-item"><i class="fa fa-bullhorn"></i> Kampanye</a>
          <a href="#" class="list-group-item"><i class="fa fa-suitcase"></i> Proyek</a>
          <a href="#" class="list-group-item"><i class="fa fa-calendar"></i> Kegiatan</a>
          <a href="#" class="list-group-item"><i class="fa fa-bars"></i> Lain</a>
        </li>
        <center>
          <a href="<?php echo e(route('session.logout')); ?>" class="btn btn-primary btn-lg">Keluar</a>  
        </center>
      </ul>
      <?php endif; ?>
      <ul class="nav navbar-nav pull-right hidden-xs">
        <!-- User Account: style can be found in dropdown.less -->
        <?php if(\Auth::check()): ?>
          <li class="dropdown user-menu pull-right hidden-xs">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo e(\Auth::user()->getPhoto(50)); ?>" class="img-circle" alt="User Image">
              <span><?php echo e(\Auth::user()->name); ?></span>
              <span class="fa fa-caret-down fa-inverse"></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo e(\Auth::user()->getPhoto(100,100)); ?>" class="img-circle" alt="User Image">
                <p>
                  <?php echo e(\Auth::user()->name); ?>

                  <small>Bergabung sejakt <?php echo e(\Auth::user()->created_at->format('%B %Y')); ?></small>
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
                <div class="list-group">
                  <a href="<?php echo e(route('user.show', auth()->user()->username)); ?>" class="list-group-item"><i class="fa fa-home"></i> Beranda</a>
                  <a href="<?php echo e(route('idea.create')); ?>" class="list-group-item"><i class="fa fa-lightbulb-o"></i> Buat Ide Baru</a>
                  <?php if(\App\Models\Member::where('user_id', auth()->user()->id)->count() > 0): ?>
                  <a href="<?php echo e(route('discuss.index')); ?>" class="list-group-item"><i class="fa fa-users"></i> Ruang Diskusi</a>
                  <?php endif; ?>
                  <a href="<?php echo e(route('user.edit', auth()->user()->username)); ?>" class="list-group-item"><i class="fa fa-pencil"></i> Perbaharui Profil</a>
                  <a href="<?php echo e(route('user.edit-password', auth()->user()->username)); ?>" class="list-group-item"><i class="fa fa-key"></i> Ganti Password</a>
                </div>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer text-center">
                <a href="<?php echo e(route('session.logout')); ?>" class="btn btn-primary btn-lg">Keluar</a>
              </li>
            </ul>
          </li>
        <?php else: ?>
          <li class="pull-right">
            <a href="<?php echo e(route('home.register')); ?>" class="btn btn-primary">Daftar</a>  
          </li>
          <li class='dropdown pull-right'>
            <a href="#" data-toggle="dropdown">Masuk</a>
            <ul class="dropdown-menu dropdown-login">
              <?php echo Form::open(['route' => 'session.login', 'method' => 'post']); ?>

                <div class="form-group">
                  <?php echo Form::text('username', old('username'), ['class' => 'form-control', 'placeholder' => 'Email/Username']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::password('password', ['class' => 'form-control', 'placeholder' => 'Password']); ?>

                </div>
                <center>
                  <?php echo Form::submit('Masuk', ['class' => 'btn btn-primary btn-lg']);; ?>

                </center>
              <?php echo Form::close(); ?>

            </ul>
          </li>
        <?php endif; ?>
      </ul>
    </div>
    <!-- /.navbar-collapse -->
  </div>
  <!-- /.container -->
</nav>

