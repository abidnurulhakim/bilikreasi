<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('home.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <h2 class="text-center text-primary header-index">
    Trending Ide
  </h2>
  <br>
  <?php echo $__env->make('home.top-idea', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>