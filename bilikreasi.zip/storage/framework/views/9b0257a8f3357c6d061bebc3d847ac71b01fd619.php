<?php if($pageHeader): ?>
  <div class="col-md-12">
    <div class="page-header">
      <div class="title">
        <?php echo e($pageTitle); ?>

      </div>
    </div>
  </div>
<?php endif; ?>