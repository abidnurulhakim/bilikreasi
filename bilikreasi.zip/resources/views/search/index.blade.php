@extends('search.layout')
@section('search-content')
  @include('search.sidebar.left')
  @include('search.sidebar.right')
@endsection