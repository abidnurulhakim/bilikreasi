@extends('layout.app')

@section('content')
  @yield('search-content')
@endsection