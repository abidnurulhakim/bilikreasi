@extends('partner.layout')
@section('partner-content')
  @include('partner.sidebar.left')
  @include('partner.sidebar.right')
@endsection