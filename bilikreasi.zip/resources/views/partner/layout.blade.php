@extends('layout.app')

@section('content')
  @yield('partner-content')
@endsection