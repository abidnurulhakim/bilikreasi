@extends('layout.app')

@section('content')
  @yield('discuss-content')
@endsection