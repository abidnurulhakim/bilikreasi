@extends('layout.app')

@section('content')
  @yield('idea-content')
@endsection