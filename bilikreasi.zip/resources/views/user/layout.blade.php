@extends('layout.app')

@section('content')
  @yield('user-sidebar-left')
  @yield('user-sidebar-right')  
@endsection