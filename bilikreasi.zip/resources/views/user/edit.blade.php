@extends('user.layout')
@section('user-sidebar-left')
  @include('user.sidebar.left')
@endsection
@section('user-sidebar-right')
  @include('user.sidebar.right-edit')
@endsection