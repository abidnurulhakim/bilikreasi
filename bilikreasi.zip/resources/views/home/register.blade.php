@extends('layout.app')

@section('content')
  <h3 class="page-header"><b class="title">Daftar</b></h3>
  @include('concerns._form-user-register')
@endsection